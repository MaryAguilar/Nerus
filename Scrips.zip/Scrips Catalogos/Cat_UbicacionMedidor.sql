USE [Arquos_V300_bak]
GO

/****** Object:  Table [Padron].[Cat_UbicacionMedidor]    Script Date: 11/21/2012 10:19:14 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [Padron].[Cat_UbicacionMedidor](
	[id_ubicacionmedidor] [numeric](10, 0) IDENTITY(0,1) NOT NULL,
	[descripcion] [varchar](50) NOT NULL,
	[inactivo] [bit] NULL,
 CONSTRAINT [PK_Cat_UbicacionMedidor] PRIMARY KEY CLUSTERED 
(
	[id_ubicacionmedidor] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


