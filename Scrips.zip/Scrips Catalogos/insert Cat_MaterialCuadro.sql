INSERT INTO [Arquos_V300_bak].[Padron].[Cat_MaterialCuadro]
           ([descripcion]
           ,[inactivo])
     VALUES
           ('Cobre', 'false'),
           ('Galvanizado', 'false'),
           ('Kitec', 'false')
GO


