INSERT INTO [Arquos_V300_bak].[Padron].[Cat_MaterialMedidor]
           ([descripcion]
           ,[inactivo])
     VALUES
          ('Bronce', 'false'),
           ('PVC', 'false')        
GO


