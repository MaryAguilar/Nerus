INSERT INTO [Arquos_V300_bak].[Padron].[Cat_TipoInstalacion]
           ([descripcion]
           ,[inactivo])
     VALUES
           ('Medidor de Piso', 'false'),
           ('Medidor Aereo', 'false') 
GO


