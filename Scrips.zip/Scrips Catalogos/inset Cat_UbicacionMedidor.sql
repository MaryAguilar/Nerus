INSERT INTO [Arquos_V300_bak].[Padron].[Cat_UbicacionMedidor]
           ([descripcion]
           ,[inactivo])
     VALUES
           ('Enfrente', 'false'),
           ('Atras', 'false'),
           ('A lado derecho', 'false'),
           ('A lado izquierdo', 'false')  
GO


